public func merrilyDream() {
    print("Merrily, merrily, merrily, merrily")
    print("Life is but a dream")
}
public func crocodileScream() {
    print("If you see a crocodile")
    print("Don't forget to scream")
}
public func repetitiveTheme() {
    print("This song is quite repetitive")
    print("Can you spot the theme")
}
public func breatheBetweenVerses() {
    print("        ~        ")
}



